<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "birds.web";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
// Agar connect ho jaye to message dikhane ke liye (baad mein hata sakte hain)
echo "Database connected successfully!";
?>